package estacionamento;

import java.util.ArrayList;
import java.util.List;
import java.time.LocalDateTime;

public class Estacionamento {
    private List<Vaga> vagas = new ArrayList<>();
    private List<Registro> registros = new ArrayList<>();

    public void cadastrarVaga(int numero, int tamanho) {
        vagas.add(new Vaga(numero, tamanho));
    }

    public void registrarEntrada(String placa, String modelo, int tamanho, LocalDateTime horaEntrada) {
        Veiculo veiculo = new Veiculo(placa, modelo, tamanho);
        Vaga vagaDisponivel = encontrarVagaDisponivel(tamanho);

        if (vagaDisponivel != null) {
            veiculo.setHoraEntrada(horaEntrada);
            vagaDisponivel.ocupar();
            registros.add(new Registro(veiculo, vagaDisponivel));
            System.out.println("Entrada registrada: Veículo " + placa + " estacionado na vaga " + vagaDisponivel.getNumero());
        } else {
            System.out.println("Nenhuma vaga disponível para o tamanho especificado.");
        }
    }

    private Vaga encontrarVagaDisponivel(int tamanho) {
        for (Vaga vaga : vagas) {
            if (vaga.isDisponivel() && vaga.getTamanho() == tamanho) {
                return vaga;
            }
        }
        return null;
    }

    public void registrarSaida(String placa, LocalDateTime horaSaida) {
        for (Registro registro : registros) {
            if (registro.getVeiculo().getPlaca().equals(placa) && !registro.getVaga().isDisponivel()) {
                registro.getVeiculo().setHoraSaida(horaSaida);
                registro.registrarSaida();
                registro.getVaga().liberar();
                System.out.println("Saída registrada: Veículo " + placa + " saiu da vaga " + registro.getVaga().getNumero());
                System.out.printf("Valor a ser pago: R$ %.2f\n", registro.getValorPago());
                return;
            }
        }
        System.out.println("Veículo não encontrado.");
    }

    public void relatorioVagasOcupadas() {
        System.out.println("Relatório de Vagas Ocupadas:");
        for (Registro registro : registros) {
            if (!registro.getVaga().isDisponivel()) {
                System.out.println("Vaga " + registro.getVaga().getNumero() + " - Tamanho: " + registro.getVaga().getTamanho() + " - Placa: " + registro.getVeiculo().getPlaca());
            }
        }
    }

    public void historicoPermanencia() {
        System.out.println("Histórico de Permanência:");
        for (Registro registro : registros) {
            System.out.println("Modelo: " + registro.getVeiculo().getModelo());
            System.out.println("Placa: " + registro.getVeiculo().getPlaca());
            System.out.println("Entrada: " + registro.getHoraEntradaFormatada());
            System.out.println("Saída: " + registro.getHoraSaidaFormatada());
            System.out.printf("Valor Pago: R$ %.2f\n", registro.getValorPago());
            System.out.println("------------------------------------");
        }
    }
}
