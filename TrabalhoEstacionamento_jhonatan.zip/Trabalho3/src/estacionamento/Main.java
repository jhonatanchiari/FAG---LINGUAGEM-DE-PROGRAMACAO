package estacionamento;

import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        Estacionamento estacionamento = new Estacionamento();
        Scanner scanner = new Scanner(System.in);
        DateTimeFormatter formatter = DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm");

        while (true) {
            System.out.println("\n=== Sistema de Estacionamento ===");
            System.out.println("1. Cadastrar Vaga");
            System.out.println("2. Registrar Entrada");
            System.out.println("3. Registrar Saída");
            System.out.println("4. Relatório de Vagas Ocupadas");
            System.out.println("5. Histórico de Permanência");
            System.out.println("6. Sair");
            System.out.print("Escolha uma opção: ");
            int opcao = scanner.nextInt();
            scanner.nextLine(); // Limpa o buffer

            switch (opcao) {
                case 1:
                    System.out.print("Número da Vaga: ");
                    int numero = scanner.nextInt();
                    System.out.print("Tamanho da Vaga (1 - Pequeno, 2 - Médio, 3 - Grande): ");
                    int tamanho = scanner.nextInt();
                    estacionamento.cadastrarVaga(numero, tamanho);
                    break;

                case 2:
                    System.out.print("Placa do Veículo: ");
                    String placa = scanner.next();
                    scanner.nextLine(); // Limpa o buffer antes de ler a linha completa
                    System.out.print("Modelo do Veículo: ");
                    String modelo = scanner.nextLine();
                    System.out.print("Tamanho do Veículo (1 - Pequeno, 2 - Médio, 3 - Grande): ");
                    int tamanhoVeiculo = scanner.nextInt();
                    scanner.nextLine(); // Limpa o buffer

                    System.out.print("Hora de Entrada (formato: yyyy-MM-dd HH:mm): ");
                    String entradaStr = scanner.nextLine();
                    LocalDateTime horaEntrada = LocalDateTime.parse(entradaStr, formatter);

                    estacionamento.registrarEntrada(placa, modelo, tamanhoVeiculo, horaEntrada);
                    break;

                case 3:
                    System.out.print("Placa do Veículo: ");
                    placa = scanner.next();
                    scanner.nextLine(); // Limpa o buffer
                    System.out.print("Hora de Saída (formato: yyyy-MM-dd HH:mm): ");
                    String saidaStr = scanner.nextLine();
                    LocalDateTime horaSaida = LocalDateTime.parse(saidaStr, formatter);

                    estacionamento.registrarSaida(placa, horaSaida);
                    break;

                case 4:
                    estacionamento.relatorioVagasOcupadas();
                    break;

                case 5:
                    estacionamento.historicoPermanencia();
                    break;

                case 6:
                    System.out.println("Encerrando sistema.");
                    scanner.close();
                    return;

                default:
                    System.out.println("Opção inválida.");
            }
        }
    }
}