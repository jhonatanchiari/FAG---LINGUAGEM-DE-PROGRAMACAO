package estacionamento;

import java.time.Duration;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter; //Formata a data e horario

public class Registro {
    private Veiculo veiculo;
    private Vaga vaga;
    private LocalDateTime horaEntrada;
    private LocalDateTime horaSaida;
    private Double valorPago;
    
    private static final DateTimeFormatter formatter = DateTimeFormatter.ofPattern("dd/MM/yyyy HH:mm:ss");

    public Registro(Veiculo veiculo, Vaga vaga) {
        this.veiculo = veiculo;
        this.vaga = vaga;
        this.horaEntrada = veiculo.getHoraEntrada();
    }

    public void registrarSaida() {
        this.horaSaida = veiculo.getHoraSaida();
        calcularValorPago();
    }

    private void calcularValorPago() {
        long duracao = Duration.between(horaEntrada, horaSaida).toHours();
        if (duracao <= 1) {
            valorPago = 5.0;
        } else if (duracao <= 3) {
            valorPago = 10.0;
        } else {
            valorPago = 15.0;
        }
    }
    
    // Método para obter hora formatada
    public String getHoraEntradaFormatada() {
        return horaEntrada.format(formatter);
    }

    public String getHoraSaidaFormatada() {
        return horaSaida != null ? horaSaida.format(formatter) : "Ainda estacionado";
    }

    public Veiculo getVeiculo() {
        return veiculo;
    }

    public Vaga getVaga() {
        return vaga;
    }

    public LocalDateTime getHoraEntrada() {
        return horaEntrada;
    }

    public LocalDateTime getHoraSaida() {
        return horaSaida;
    }

    public Double getValorPago() {
        return valorPago;
    }
}
