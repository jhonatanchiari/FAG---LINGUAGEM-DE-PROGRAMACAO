package estacionamento;

public class Vaga {

    private int numero;
    private int tamanho; // 1 - Pequeno, 2 - Médio, 3 - Grande
    private boolean disponivel;

    // Construtor
    public Vaga(int numero, int tamanho) {
        this.numero = numero;
        this.tamanho = tamanho;
        this.disponivel = true; // inicia a vaga como disponível
    }

    public int getNumero() {
        return numero;
    }

    public int getTamanho() {
        return tamanho;
    }

    public boolean isDisponivel() {
        return disponivel;
    }

    // Método para ocupar a vaga
    public void ocupar() {
        this.disponivel = false;
    }

    // Método para liberar a vaga
    public void liberar() {
        this.disponivel = true;
    }
}
