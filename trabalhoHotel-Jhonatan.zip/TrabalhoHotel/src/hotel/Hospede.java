package hotel;

public class Hospede {
	private String nome;

	public Hospede(String nome) {
		this.nome = nome;
	}

	public String getNome() {
		return nome;
	}

	@Override
	public String toString() {
		return nome;
	}
}
