package hotel;

import java.util.ArrayList;
import java.util.List;
import java.time.LocalDate;

public class Hotel {
	private List<Quarto> quartos;
	private List<Reserva> reservas;
	private List<Hospede> hospedes;

	public Hotel() {
		quartos = new ArrayList<>();
		reservas = new ArrayList<>();
		hospedes = new ArrayList<>();
	}

	// Cadastro de quartos
	public void cadastrarQuarto(int numero, int tipo, double precoDiario) {
		Quarto quarto = new Quarto(numero, tipo, precoDiario);
		quartos.add(quarto);
	}

	// Cadastro de reservas
	public void cadastrarReserva(String nomeHospede, LocalDate checkIn, LocalDate checkOut, int numeroQuartos,
			int tipoQuarto) {
		Reserva reserva = new Reserva(nomeHospede, checkIn, checkOut, numeroQuartos, tipoQuarto);
		reservas.add(reserva);
		hospedes.add(new Hospede(nomeHospede));
		atualizarDisponibilidade(tipoQuarto, false); // Marca o quarto como ocupado
	}

	// Registro de check-in
	public void realizarCheckIn(String nomeHospede) {
		for (Reserva reserva : reservas) {
			if (reserva.getNomeHospede().equals(nomeHospede)) {
				System.out.println("Check-in realizado para: " + nomeHospede);
				return;
			}
		}
		System.out.println("Reserva não encontrada.");
	}

	// Registro de check-out
	public void realizarCheckOut(String nomeHospede) {
		for (Reserva reserva : reservas) {
			if (reserva.getNomeHospede().equals(nomeHospede)) {
				System.out.println("Check-out realizado para: " + nomeHospede);
				atualizarDisponibilidade(reserva.getTipoQuarto(), true); // Agora passando o tipo de quarto corretamente
																			// como inteiro
				return;
			}
		}
		System.out.println("Reserva não encontrada.");
	}

	// Atualizar disponibilidade do quarto
	private void atualizarDisponibilidade(int tipoQuarto, boolean disponivel) {
		for (Quarto quarto : quartos) {
			if (quarto.getTipo() == tipoQuarto && quarto.isDisponivel() != disponivel) {
				quarto.setDisponivel(disponivel);
				break;
			}
		}
	}

	// Relatório de ocupação de quartos
	public void relatorioOcupacao() {
		boolean algumOcupado = false;
		System.out.println("Relatório de ocupação de quartos:");

		for (Quarto quarto : quartos) {
			if (!quarto.isDisponivel()) {
				System.out.println(quarto);
				algumOcupado = true;
			}
		}

		if (!algumOcupado) {
			System.out.println("Nenhum quarto está ocupado no momento.");
		}
	}

	// Histórico de reservas por hóspede
	public void historicoReservas(String nomeHospede) {
		System.out.println("Histórico de reservas para: " + nomeHospede);
		for (Reserva reserva : reservas) {
			if (reserva.getNomeHospede().equals(nomeHospede)) {
				System.out.println(reserva);
			}
		}
	}
}
