package hotel;

public class Quarto {
    private int numero;
    private int tipo;  // Tipo de quarto como inteiro
    private double precoDiario;
    private boolean disponivel;

    public Quarto(int numero, int tipo, double precoDiario) {
        this.numero = numero;
        this.tipo = tipo;
        this.precoDiario = precoDiario;
        this.disponivel = true;  // Quando criado, o quarto está disponível
    }

    public int getNumero() {
        return numero;
    }

    public int getTipo() {  // Retornando o tipo de quarto como inteiro
        return tipo;
    }

    public double getPrecoDiario() {
        return precoDiario;
    }

    public boolean isDisponivel() {
        return disponivel;
    }

    public void setDisponivel(boolean disponivel) {
        this.disponivel = disponivel;
    }

    @Override
    public String toString() {
        String tipoQuartoStr = "";
        switch (tipo) {
            case 1:
                tipoQuartoStr = "Solteiro";
                break;
            case 2:
                tipoQuartoStr = "Casal";
                break;
            case 3:
                tipoQuartoStr = "Suíte";
                break;
        }
        return "Quarto [Número: " + numero + ", Tipo: " + tipoQuartoStr + ", Preço: " + precoDiario + ", Disponível: " + disponivel + "]";
    }
}
