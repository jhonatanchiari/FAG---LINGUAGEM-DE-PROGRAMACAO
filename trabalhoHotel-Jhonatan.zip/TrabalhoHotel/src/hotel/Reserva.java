package hotel;

import java.time.LocalDate;

public class Reserva {
    private String nomeHospede;
    private LocalDate checkIn;
    private LocalDate checkOut;
    private int numeroQuartos;
    private int tipoQuarto;  // Tipo de quarto como inteiro

    public Reserva(String nomeHospede, LocalDate checkIn, LocalDate checkOut, int numeroQuartos, int tipoQuarto) {
        this.nomeHospede = nomeHospede;
        this.checkIn = checkIn;
        this.checkOut = checkOut;
        this.numeroQuartos = numeroQuartos;
        this.tipoQuarto = tipoQuarto;
    }

    public String getNomeHospede() {
        return nomeHospede;
    }

    public LocalDate getCheckIn() {
        return checkIn;
    }

    public LocalDate getCheckOut() {
        return checkOut;
    }

    public int getNumeroQuartos() {
        return numeroQuartos;
    }

    public int getTipoQuarto() {  // Retornando o tipo do quarto como inteiro
        return tipoQuarto;
    }

    @Override
    public String toString() {
        return "Reserva [Hóspede: " + nomeHospede + ", Check-in: " + checkIn + ", Check-out: " + checkOut +
                ", Número de quartos: " + numeroQuartos + ", Tipo de quarto: " + tipoQuarto + "]";
    }
}
