package hotel;

import java.util.Scanner;
import java.time.LocalDate;

public class SistemaPrincipal {
    public static void main(String[] args) {
        Hotel hotel = new Hotel();
        Scanner sc = new Scanner(System.in);

        // Exemplo de navegação pela interface
        int opcao;
        do {
            System.out.println("\n--- Sistema de Gerenciamento de Hotel ---");
            System.out.println("1. Cadastrar Quarto");
            System.out.println("2. Cadastrar Reserva");
            System.out.println("3. Realizar Check-in");
            System.out.println("4. Realizar Check-out");
            System.out.println("5. Relatório de Ocupação de Quartos");
            System.out.println("6. Histórico de Reservas");
            System.out.println("0. Sair");
            System.out.print("Escolha uma opção: ");
            opcao = sc.nextInt();

            switch (opcao) {
                case 1:
                    System.out.print("Número do quarto: ");
                    int numero = sc.nextInt();
                    System.out.println("Tipo do quarto: 1 - Solteiro, 2 - Casal, 3 - Suíte");
                    int tipo = sc.nextInt();
                    System.out.print("Preço diário: ");
                    double preco = sc.nextDouble();
                    hotel.cadastrarQuarto(numero, tipo, preco);
                    break;
                case 2:
                    sc.nextLine(); // Consumir quebra de linha
                    System.out.print("Nome do hóspede: ");
                    String nomeHospede = sc.nextLine();
                    System.out.print("Data de check-in (AAAA-MM-DD): ");
                    LocalDate checkIn = LocalDate.parse(sc.nextLine());
                    System.out.print("Data de check-out (AAAA-MM-DD): ");
                    LocalDate checkOut = LocalDate.parse(sc.nextLine());
                    System.out.print("Número de quartos reservados: ");
                    int numeroQuartos = sc.nextInt();
                    System.out.println("Tipo de quarto: 1 - Solteiro, 2 - Casal, 3 - Suíte");
                    int tipoQuarto = sc.nextInt();
                    hotel.cadastrarReserva(nomeHospede, checkIn, checkOut, numeroQuartos, tipoQuarto);
                    break;
                case 3:
                    sc.nextLine(); // Consumir quebra de linha
                    System.out.print("Nome do hóspede: ");
                    String hospedeCheckIn = sc.nextLine();
                    hotel.realizarCheckIn(hospedeCheckIn);
                    break;
                case 4:
                    sc.nextLine(); // Consumir quebra de linha
                    System.out.print("Nome do hóspede: ");
                    String hospedeCheckOut = sc.nextLine();
                    hotel.realizarCheckOut(hospedeCheckOut);
                    break;
                case 5:
                    hotel.relatorioOcupacao();
                    break;
                case 6:
                    sc.nextLine(); // Consumir quebra de linha
                    System.out.print("Nome do hóspede: ");
                    String hospedeHistorico = sc.nextLine();
                    hotel.historicoReservas(hospedeHistorico);
                    break;
                case 0:
                    System.out.println("Saindo do sistema...");
                    break;
                default:
                    System.out.println("Opção inválida.");
            }
        } while (opcao != 0);

        sc.close();
    }
}
