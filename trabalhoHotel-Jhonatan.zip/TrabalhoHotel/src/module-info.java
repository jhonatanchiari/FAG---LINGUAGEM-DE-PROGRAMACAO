/**
 * 
 */
/**
 * 
 */
module TrabalhoHotel {
}